<?php
session_start();
require_once "veritabani.php";
if (!isset($_SESSION["musteri_id"])) {
    header("Location: giris.php");
    exit;
}
// id al ve kontrol et
if (empty($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: arac_listele.php");
    exit;
}
$arac_id = (int)$_GET['id'];
// ENUM dizileri
$turler   = ["SUV","Agir","CiftTeker","DortTeker"];
$durumlar = ["galeride","kirada","satildi"];
$hata = "";
// Başlangıçta form alanları boş
$marka = $model = $yil = $plaka = $fiyat = "";
$tur = $durum = "";
// POST ile gelinmişse işlem yap
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $marka = trim($_POST["marka"] ?? "");
    $model = trim($_POST["model"] ?? "");
    $yil   = trim($_POST["yil"] ?? "");
    $plaka = trim($_POST["plaka"] ?? "");
    $fiyat = trim($_POST["fiyat"] ?? "");
    $tur   = $_POST["tur"] ?? "";
    $durum = $_POST["durum"] ?? "";
    $personel_id = 1;
    if ($marka===""||$model===""||$yil===""||$plaka===""||$fiyat===""||$tur===""||$durum==="") {
        $hata = "Tüm alanları doldurun.";
    } elseif (!is_numeric($yil) || (int)$yil<1900 || (int)$yil> (int)date("Y")+1) {
        $hata = "Geçerli yıl giriniz.";
    } elseif (!is_numeric($fiyat) || (float)$fiyat<0) {
        $hata = "Geçerli fiyat giriniz.";
    } elseif (!in_array($tur, $turler, true)) {
        $hata = "Geçersiz tür seçimi.";
    } elseif (!in_array($durum, $durumlar, true)) {
        $hata = "Geçersiz durum seçimi.";
    } else {
        $sql = "UPDATE arac SET marka=?, model=?, yil=?, plaka=?, fiyat=?, tur=?, durum=?, personel_id=? WHERE arac_id=?";
        $stmt = $baglanti->prepare($sql);
        if ($stmt) {
            $yil_i = (int)$yil;
            $fiyat_f = (float)$fiyat;
            $aid = $arac_id;
            // s,s,i,s,d,s,s,i,i
            $stmt->bind_param("ssisdssii",
                $marka, $model, $yil_i, $plaka, $fiyat_f, $tur, $durum, $personel_id, $aid
            );
            if ($stmt->execute()) {
                header("Location: arac_listele.php");
                exit;
            } else {
                $hata = "Güncellerken hata: ".$stmt->error;
            }
        } else {
            $hata = "DB hata: ".$baglanti->error;
        }
    }
}
// GET veya POST sonrası (hata varsa) formu doldurmak için DB’den oku
if ($_SERVER["REQUEST_METHOD"] !== "POST" || $hata!=="") {
    $sql = "SELECT * FROM arac WHERE arac_id=?";
    $stmt = $baglanti->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i",$arac_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if (!$row) {
            header("Location: arac_listele.php");
            exit;
        }
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            $marka = $row['marka'];
            $model = $row['model'];
            $yil   = $row['yil'];
            $plaka = $row['plaka'];
            $fiyat = $row['fiyat'];
            $tur   = $row['tur'];
            $durum = $row['durum'];
        }
    } else {
        die("DB hata: ".$baglanti->error);
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Araç Düzenle</title>
<style>
body{font-family:Arial,sans-serif;margin:20px;}
.kutu{max-width:400px;margin:30px auto;padding:20px;background:#f4f4f4;border:1px solid #ccc;border-radius:6px;}
input,select{width:100%;padding:8px;margin-bottom:12px;border:1px solid #aaa;border-radius:4px;box-sizing:border-box;}
button{width:100%;padding:10px;background:#007bff;color:#fff;border:none;font-size:16px;cursor:pointer;border-radius:4px;}
button:hover{background:#0056b3;}
.hata{color:red;text-align:center;margin-bottom:12px;}
.links{text-align:center;margin-top:15px;}
.links a{color:blue;text-decoration:none;margin:0 10px;font-size:14px;}
.links a:hover{text-decoration:underline;}
h2{text-align:center;}
</style>
</head>
<body>
<div class="kutu">
    <h2>Araç Düzenle (ID: <?=htmlspecialchars($arac_id)?>)</h2>
    <?php if($hata!==""):?><div class="hata"><?=htmlspecialchars($hata)?></div><?php endif;?>
    <form method="POST">
        <input type="text" name="marka" placeholder="Marka" required value="<?=htmlspecialchars($marka)?>">
        <input type="text" name="model" placeholder="Model" required value="<?=htmlspecialchars($model)?>">
        <input type="number" name="yil" placeholder="Yıl" required min="1900" max="<?=date("Y")?>" value="<?=htmlspecialchars($yil)?>">
        <input type="text" name="plaka" placeholder="Plaka" required value="<?=htmlspecialchars($plaka)?>">
        <input type="number" step="0.01" name="fiyat" placeholder="Fiyat" required value="<?=htmlspecialchars($fiyat)?>">
        <select name="tur" required>
            <option value="">Tür Seçiniz</option>
            <?php foreach($turler as $t): ?>
                <option value="<?=htmlspecialchars($t)?>" <?=($tur===$t)?"selected":""?>><?=htmlspecialchars($t)?></option>
            <?php endforeach; ?>
        </select>
        <select name="durum" required>
            <option value="">Durum Seçiniz</option>
            <?php foreach($durumlar as $d): ?>
                <option value="<?=htmlspecialchars($d)?>" <?=($durum===$d)?"selected":""?>><?=htmlspecialchars($d)?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Güncelle</button>
    </form>
    <div class="links">
        <a href="arac_listele.php">Araç Listesine Dön</a> |
        <a href="panel.php">Panele Dön</a>
    </div>
</div>
</body>
</html>
