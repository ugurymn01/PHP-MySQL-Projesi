<?php
header("Location: oto_sistem/giris.php");
exit;
?>
