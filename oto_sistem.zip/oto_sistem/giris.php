<?php
session_start();
require_once "veritabani.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $sifre = $_POST["sifre"];

    $sql = "SELECT musteri_id, sifre FROM musteri WHERE email = ?";
    $stmt = $baglanti->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($musteri_id, $hashli_sifre);
        $stmt->fetch();

        if (password_verify($sifre, $hashli_sifre)) {
            $_SESSION["musteri_id"] = $musteri_id;
            header("Location: panel.php");
            exit;
        } else {
            $hata = "Şifre yanlış.";
        }
    } else {
        $hata = "Kullanıcı bulunamadı.";
    }

    $stmt->close();
    $baglanti->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .kutu {
            max-width: 350px;
            margin: 100px auto;
            padding: 20px;
            background-color: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        h2 {
            text-align: center;
        }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #aaa;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #008CBA;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #005f73;
        }
        .hata {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
        .linkler {
            text-align: center;
            margin-top: 15px;
        }
        .linkler a {
            text-decoration: none;
            color: blue;
            margin: 0 10px;
            font-size: 14px;
        }
        .linkler a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="kutu">
    <h2>Giriş Yap</h2>
    <?php if (isset($hata)) echo "<div class='hata'>$hata</div>"; ?>
    <form method="POST">
        <input type="email" name="email" placeholder="E-Posta" required>
        <input type="password" name="sifre" placeholder="Şifre" required>
        <button type="submit">Giriş</button>
    </form>
    <div class="linkler">
        <a href="kayit.php">Kayıt Ol</a>
    </div>
</div>

</body>
</html>
