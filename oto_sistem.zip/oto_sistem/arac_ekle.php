<?php
session_start();
require_once "veritabani.php";

// Giriş kontrolü
if (!isset($_SESSION["musteri_id"])) {
    header("Location: giris.php");
    exit;
}

// Orijinal TUR ENUM seçenekleri
$gecerliTurler   = ["SUV", "Agir", "CiftTeker", "DortTeker"];
$gecerliDurumlar = ["galeride", "kirada", "satildi"];

// Başlangıç değerleri
$hata = "";
$marka = $model = $yil = $plaka = $fiyat = "";
$tur = "";
$durum = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // POST verilerini al
    $marka = trim($_POST["marka"]   ?? "");
    $model = trim($_POST["model"]   ?? "");
    $yil   = trim($_POST["yil"]     ?? "");
    $plaka = trim($_POST["plaka"]   ?? "");
    $fiyat = trim($_POST["fiyat"]   ?? "");
    $tur   = $_POST["tur"]   ?? "";
    $durum = $_POST["durum"] ?? "";
    $personel_id = 1; // sabit veya session’dan alabilirsin

    // Basit doğrulama
    if ($marka === "" || $model === "" || $yil === "" || $plaka === "" || $fiyat === "" || $tur === "" || $durum === "") {
        $hata = "Lütfen tüm alanları doldurun.";
    } else {
        // Yıl ve fiyat kontrolü
        if (!is_numeric($yil) || (int)$yil < 1900 || (int)$yil > (int)date("Y")+1) {
            $hata = "Geçerli bir yıl giriniz.";
        } elseif (!is_numeric($fiyat) || (float)$fiyat < 0) {
            $hata = "Geçerli bir fiyat giriniz.";
        } elseif (!in_array($tur, $gecerliTurler, true)) {
            $hata = "Geçersiz araç türü seçimi: " . htmlspecialchars($tur);
        } elseif (!in_array($durum, $gecerliDurumlar, true)) {
            $hata = "Geçersiz durum seçimi: " . htmlspecialchars($durum);
        } else {
            // INSERT işlemi
            $sql = "INSERT INTO arac (marka, model, yil, plaka, fiyat, tur, durum, personel_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $baglanti->prepare($sql);
            if (!$stmt) {
                $hata = "Prepare hatası: " . $baglanti->error;
            } else {
                // bind_param referans sorunu olmaması için geçici değişkenler
                $yil_int = (int)$yil;
                $fiyat_float = (float)$fiyat;
                // Tip sırası: s, s, i, s, d, s, s, i  => "ssisdssi"
                $stmt->bind_param(
                    "ssisdssi",
                    $marka,
                    $model,
                    $yil_int,
                    $plaka,
                    $fiyat_float,
                    $tur,
                    $durum,
                    $personel_id
                );
                if ($stmt->execute()) {
                    header("Location: arac_listele.php");
                    exit;
                } else {
                    $hata = "Araç eklenirken hata oluştu: " . $stmt->error;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Araç Ekle</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .kutu {
            max-width: 400px;
            margin: 30px auto;
            padding: 20px;
            background: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        h2 { text-align: center; }
        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #aaa;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #008CBA;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }
        button:hover {
            background: #005f73;
        }
        .hata {
            color: red;
            text-align: center;
            margin-bottom: 12px;
        }
        .links {
            text-align: center;
            margin-top: 15px;
        }
        .links a {
            color: blue;
            text-decoration: none;
            margin: 0 10px;
            font-size: 14px;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="kutu">
    <h2>Yeni Araç Ekle</h2>

    <?php if ($hata !== ""): ?>
        <div class="hata"><?= htmlspecialchars($hata) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="marka" placeholder="Marka" required value="<?= htmlspecialchars($marka) ?>">
        <input type="text" name="model" placeholder="Model" required value="<?= htmlspecialchars($model) ?>">
        <input type="number" name="yil" placeholder="Yıl" required min="1900" max="<?= date("Y") ?>" value="<?= htmlspecialchars($yil) ?>">
        <input type="text" name="plaka" placeholder="Plaka" required value="<?= htmlspecialchars($plaka) ?>">
        <input type="number" step="0.01" name="fiyat" placeholder="Fiyat" required value="<?= htmlspecialchars($fiyat) ?>">

        <select name="tur" required>
            <option value="">Tür Seçiniz</option>
            <?php foreach ($gecerliTurler as $t): ?>
                <option value="<?= htmlspecialchars($t) ?>" <?= ($tur === $t) ? "selected" : "" ?>>
                    <?= htmlspecialchars($t) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="durum" required>
            <option value="">Durum Seçiniz</option>
            <?php foreach ($gecerliDurumlar as $d): ?>
                <option value="<?= htmlspecialchars($d) ?>" <?= ($durum === $d) ? "selected" : "" ?>>
                    <?= htmlspecialchars($d) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Ekle</button>
    </form>

    <div class="links">
        <a href="arac_listele.php">Araç Listesine Dön</a> |
        <a href="panel.php">Panele Dön</a>
    </div>
</div>

</body>
</html>
