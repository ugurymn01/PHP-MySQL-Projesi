<?php
session_start();
require_once "veritabani.php";

if (!isset($_SESSION["musteri_id"])) {
    header("Location: giris.php");
    exit;
}

$sql = "SELECT * FROM arac";
$sonuc = $baglanti->query($sql);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Araç Listesi</title>
    <style>
        /* Sayfa kenar boşluğu ve font */
        body {
            margin: 20px;
            font-family: Arial, sans-serif;
        }

        /* Başlık ortalı */
        h2 {
            text-align: center;
        }

        /* Tablo kenarlıklı, hücre içleri dolu */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        /* Hücre kenar çizgisi */
        th, td {
            border: 1px solid black;
            padding: 6px;
            text-align: center;
        }

        /* Başlık hücre rengi açık gri */
        th {
            background-color: #ddd;
        }

        /* Buton benzeri link stili */
        a.button {
            background-color: #008CBA;
            color: white;
            padding: 5px 12px;
            text-decoration: none;
            border-radius: 3px;
            font-size: 14px;
        }

        /* Sayfa altındaki linkler aralığı */
        .links {
            margin-top: 15px;
            text-align: center;
        }

        .links a {
            margin: 0 10px;
            color: blue;
            text-decoration: none;
            font-size: 14px;
        }

    </style>
</head>
<body>

<h2>Araç Listesi</h2>

<table>
    <tr>
        <th>
            ID
        </th>
        <th>
            MARKA
        </th>
        <th>
            MODEL
        </th>
        <th>
            YIL
        </th>
        <th>
            PLAKA
        </th>
        <th>
            FİYAT
        </th>
        <th>
            TÜR
        </th>
        <th>
            DURUM
        </th>
        <th>
            İŞLEM
        </th>
    </tr>

    <?php while ($arac = $sonuc->fetch_assoc()): ?>
    <tr>
        <td>
            <?= $arac["arac_id"] ?>
        </td>
        <td>
            <?= $arac["marka"] ?>
        </td>
        <td>
            <?= $arac["model"] ?>
        </td>
        <td>
            <?= $arac["yil"] ?>
        </td>
        <td>
            <?= $arac["plaka"] ?>
        </td>
        <td>
            <?= $arac["fiyat"] ?>
        </td>
        <td>
            <?= $arac["tur"] ?>
        </td>
        <td>
            <?= $arac["durum"] ?>
        </td>
        <td>
            <a href="arac_duzenle.php?id=<?= $arac['arac_id'] ?>" class="button">Düzenle</a>
            <a href="arac_sil.php?id=<?= $arac['arac_id'] ?>" class="button" onclick="return confirm('Silmek istediğine emin misin?')">Sil</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<div class="links">
    <a href="arac_ekle.php">YENİ ARAÇ EKLE</a> |
    <a href="panel.php">PANELE DÖN</a> |
    <a href="cikis.php">ÇIKIŞ YAP</a>
</div>

</body>
</html>
