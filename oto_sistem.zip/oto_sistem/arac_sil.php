<?php
session_start();
require_once "veritabani.php";

if (!isset($_SESSION["musteri_id"])) {
    header("Location: giris.php");
    exit;
}

if (isset($_GET["id"])) {
    $arac_id = $_GET["id"];

    $sql = "DELETE FROM arac WHERE arac_id = ?";
    $stmt = $baglanti->prepare($sql);
    $stmt->bind_param("i", $arac_id);

    if ($stmt->execute()) {
        header("Location: arac_listele.php");
        exit;
    } else {
        echo "❌ Silme işlemi başarısız: " . $stmt->error;
    }

    $stmt->close();
    $baglanti->close();
} else {
    echo "❗️ Silinecek araç ID'si belirtilmedi.";
}
