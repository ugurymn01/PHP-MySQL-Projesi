<?php
session_start();
require_once "veritabani.php";

if (!isset($_SESSION["musteri_id"])) {
    header("Location: giris.php");
    exit;
}

// Toplam araç sayısını al
$sql = "SELECT COUNT(*) AS toplam FROM arac";
$result = $baglanti->query($sql);
$row = $result->fetch_assoc();
$toplam_arac = $row['toplam'];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        h2 {
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #f4f4f4;
            padding: 20px;
            border-radius: 6px;
        }
        .info {
            text-align: center;
            margin-bottom: 20px;
            font-size: 18px;
            color: #333;
        }
        .btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 18px;
            margin: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
        }
        .btn-red {
            background-color: #dc3545;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Hoşgeldin!</h2>

    <p class="info">Sistemde toplam <strong><?= $toplam_arac ?></strong> araç bulunuyor.</p>

    <div style="text-align:center;">
        <a href="arac_listele.php" class="btn">Araçları Listele</a>
        <a href="arac_ekle.php" class="btn">Yeni Araç Ekle</a>
        <a href="cikis.php" class="btn btn-red">Çıkış Yap</a>
    </div>
</div>

</body>
</html>
