<?php
$servername = "localhost";                 
$username   = "dbusr22360859023";          
$password   = "6gVhVTQBLsv5";               
$database   = "dbstorage22360859023";      

$baglanti = new mysqli($servername, $username, $password, $database);
if ($baglanti->connect_error) {
    die("DB bağlantı hatası: " . $baglanti->connect_error);
}

$baglanti->set_charset("utf8mb4");
?>
