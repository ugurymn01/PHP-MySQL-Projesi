<?php
require_once "veritabani.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad = $_POST["ad"];
    $soyad = $_POST["soyad"];
    $tc_no = $_POST["tc_no"];
    $telefon = $_POST["telefon"];
    $email = $_POST["email"];
    $sifre = password_hash($_POST["sifre"], PASSWORD_DEFAULT);

    // Varsayılan şube id
    $sube_id = 1;

    $sql = "INSERT INTO musteri (sube_id, tc_no, ad, soyad, telefon, email, sifre)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bind_param("issssss", $sube_id, $tc_no, $ad, $soyad, $telefon, $email, $sifre);

    if ($stmt->execute()) {
        header("Location: giris.php");
        exit;
    } else {
        $hata = "Kayıt sırasında hata oluştu: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .kutu {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        h2 {
            text-align: center;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #aaa;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .hata {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
        .linkler {
            text-align: center;
            margin-top: 15px;
        }
        .linkler a {
            text-decoration: none;
            color: blue;
            margin: 0 10px;
        }
        .linkler a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="kutu">
    <h2>Kayıt Ol</h2>

    <?php if (isset($hata)) echo "<div class='hata'>$hata</div>"; ?>

    <form method="POST">
        <input type="text" name="ad" placeholder="Ad" required>
        <input type="text" name="soyad" placeholder="Soyad" required>
        <input type="text" name="tc_no" placeholder="TC No" required>
        <input type="text" name="telefon" placeholder="Telefon" required>
        <input type="email" name="email" placeholder="E-posta" required>
        <input type="password" name="sifre" placeholder="Şifre" required>
        <button type="submit">Kayıt Ol</button>
    </form>

    <div class="linkler">
        <a href="giris.php">Giriş Yap</a>
        <a href="panel.php">Panele Dön</a>
    </div>
</div>

</body>
</html>
